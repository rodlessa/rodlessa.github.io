function showPoly(0){
  alert(new QRCode(document.getElementById("polygon"), "0x3d71311D333594DBFD64d2f0D1A3b5Dd46569fC3"));
}

// new QRCode(document.getElementById("nano"), "nano_1u55suaiojki8hj5kgtein4k5ndw17r45ty766puzjjxw6z7uw1atrzwz4fo");
//new QRCode(document.getElementById("bsc"), "https://webisora.com");
//new QRCode(document.getElementById("polygon"), "0x3d71311D333594DBFD64d2f0D1A3b5Dd46569fC3");
//new QRCode(document.getElementById("btc"), "1BWiGQXapZYG9qYi7ZXQKYKa8RDbMgGVVN");
//
